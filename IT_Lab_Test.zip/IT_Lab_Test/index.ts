﻿const mongoose = require("mongoose");
const express = require("express");
const app = express();
const API_PORT = 5000;
app.use(express.json());
app.listen(API_PORT, () =>
	console.log("Listening on port " + API_PORT + "..."),
);

// DB connection
mongoose
	.connect("mongodb://localhost:27017/IT_Lab_Test", { useNewUrlParser: true })
	.then(() => console.log("Connected to MongoDB!"))
	.catch((error) => console.error("Could not connect to MongoDB... ", error));

// Creating report schema
const reportSchema = new mongoose.Schema({
	key: String,
	value: Number,
});

// Creating tracking schema
const trackingSchema = new mongoose.Schema({
	json: Object,
	count: Number,
});

// Creating collections Report and Tracking
const Report = mongoose.model("Report", reportSchema);
const Tracking = mongoose.model("Tracking", trackingSchema);

// First item in Report, should be uncommented in first run

/*
Report.create({
	key: "counter",
	value: 0,
});
*/

let id: string = "";
let countValue: number = 0;

// getCount returns actual value of counter in Report
// it also stores the id and countValue variables
async function getCount() {
	let count = await Report.find()
		.select("value");
	id = count.toString().split(" ")[3].split('"')[1];
	count = parseInt(count.toString().split(" ")[5]);
	countValue = count;
	return count;
}

// The function AddUp is purely demonstrative for unit test verification
function AddUp(numbers:number[]) {
	let result:number = 0;
	for (const numberValue of numbers) {
		result += numberValue;
	}
	return result;
}

// To save id and countValue
getCount();

// GET requirement
app.get("/it_lab_test/count", (req, res): void => {
	getCount()
		.then((count:number) => {
			if (count) res.send("Value is " + count);
			else res.status(404).send("Value is 0");
			countValue = count;
		})
		.catch((err) => {
			res.status(400).send("Chyba pozadavku GET!");
		});
});

// POST requirement
app.post("/it_lab_test/track", (req, res): void => {
	let parametres = req.body;
	// Determines if a non-zero number is stored
	if (req.body.count && typeof req.body.count == 'number') {
		getCount();
		Report.findByIdAndUpdate(id, { key: "counter", value: AddUp([countValue, req.body.count]) }, { new: true })
			.catch((err) => {
				res.send("Nepodarilo se ulozit counter!");
			})	
	} else {
		parametres.count = 0;
	}
	Tracking.create(parametres)
		.then((result) => {
			res.json(result);
		})
		.catch((err) => {
			res.send("Nepodarilo se ulozit zaznam! Ulozte vsechny vlastnosti do objektu 'json'!");
		});
});

// export AddUp for unit test
// exports.AddUp = AddUp;