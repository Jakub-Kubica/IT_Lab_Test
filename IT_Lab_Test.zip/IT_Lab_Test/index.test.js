const { AddUp } = require('./index');

test('adds the different numbers and compares them with the output', () => {
    expect(AddUp([1, 2])).toBe(3);
    expect(AddUp([5, 10])).toBe(15);
    expect(AddUp([0, 8])).toBe(8);
});